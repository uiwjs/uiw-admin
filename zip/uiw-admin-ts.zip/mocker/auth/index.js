module.exports.authList = [
  '/tableList',
  '/home',
  '/demo',
  '/dom',
  '/dom/*',
  '/exceptions',
  '/exceptions/403',
  '/exceptions/404',
  '/exceptions/500',
]
