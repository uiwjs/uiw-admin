
import ModelsDocDoc from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc";
import ModelsDemo from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo";
import ModelsGlobal from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global";
import ModelsHome from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home";
import ModelsLogin from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login";
import PagesDashboardModelsIndex from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/pages/Dashboard/models/index";
import PagesDemoModelsIndex from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/pages/Demo/models/index";
import PagesFormModelsIndex from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/pages/Form/models/index";
export interface ModelsType {	doc:typeof ModelsDocDoc,
	demo:typeof ModelsDemo,
	global:typeof ModelsGlobal,
	home:typeof ModelsHome,
	login:typeof ModelsLogin,
	docDs:typeof PagesDashboardModelsIndex,
	docD:typeof PagesDemoModelsIndex,
	form:typeof PagesFormModelsIndex,} 
export default {
	doc:ModelsDocDoc,
	demo:ModelsDemo,
	global:ModelsGlobal,
	home:ModelsHome,
	login:ModelsLogin,
	docDs:PagesDashboardModelsIndex,
	docD:PagesDemoModelsIndex,
	form:PagesFormModelsIndex,
}
