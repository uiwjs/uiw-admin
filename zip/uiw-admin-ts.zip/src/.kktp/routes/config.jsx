
import React from "react";
import { Navigate } from "react-router-dom";

import Components0LayoutsUserLayout from "@/layouts/UserLayout";

import Components1LayoutsBasicLayout from "@/layouts/BasicLayout";

import Components2PagesTableList from "@/pages/TableList";

import Components3PagesDemo from "@/pages/Demo";

import Components4PagesForm from "@/pages/Form";

import Components5UiwAdminExceptionsEsmExceptions403 from "@uiw-admin/exceptions/esm/Exceptions/403";

import Components6UiwAdminExceptionsEsmExceptions500 from "@uiw-admin/exceptions/esm/Exceptions/500";

import Components7UiwAdminExceptionsEsmExceptions404 from "@uiw-admin/exceptions/esm/Exceptions/404";


export default [{
  "path": "/login",
  "element": React.lazy(() => import("@/layouts/UserLayout")),
  loader: Components0LayoutsUserLayout.loader
}, {
  "path": "/",
  "element": React.lazy(() => import("@/layouts/BasicLayout")),
  "children": [{
    "index": true,
    "redirect": "/home",
    element: <Navigate to="/home" />
  }, {
    "path": "/home",
    "name": "首页",
    "element": React.lazy(() => import("@/pages/TableList")),
    "icon": "home",
    loader: Components2PagesTableList.loader
  }, {
    "path": "/demo",
    "name": "列表查询/新增",
    "element": React.lazy(() => import("@/pages/Demo")),
    "icon": "home",
    loader: Components3PagesDemo.loader
  }, {
    "path": "/form",
    "name": "高级表单",
    "element": React.lazy(() => import("@/pages/Form")),
    "icon": "document",
    loader: Components4PagesForm.loader
  }, {
    "path": "/:group/*",
    "name": "测试点击页面",
    "hideInMenu": true,
    "component": "@/pages/TableList",
    "icon": "home"
  }, {
    "path": "/dom/exceptions",
    "name": "异常",
    "icon": "warning-o",
    "side": false,
    "children": [{
      "index": true,
      "redirect": "/dom/exceptions/403",
      element: <Navigate to="/dom/exceptions/403" />
    }, {
      "path": "/dom/exceptions/403",
      "name": "403",
      "element": React.lazy(() => import("@uiw-admin/exceptions/esm/Exceptions/403")),
      loader: Components5UiwAdminExceptionsEsmExceptions403.loader
    }, {
      "path": "/dom/exceptions/500",
      "name": "500",
      "element": React.lazy(() => import("@uiw-admin/exceptions/esm/Exceptions/500")),
      loader: Components6UiwAdminExceptionsEsmExceptions500.loader
    }, {
      "path": "/dom/exceptions/404",
      "name": "404",
      "element": React.lazy(() => import("@uiw-admin/exceptions/esm/Exceptions/404")),
      loader: Components7UiwAdminExceptionsEsmExceptions404.loader
    }]
  }],
  loader: Components1LayoutsBasicLayout.loader
}];
