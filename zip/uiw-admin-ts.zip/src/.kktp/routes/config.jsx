
import React from "react";
import { Navigate } from "react-router-dom";

import Components0LayoutsUserLayout from "@/layouts/UserLayout";

import Components1LayoutsBasicLayout from "@/layouts/BasicLayout";

import Components2PagesTableList from "@/pages/TableList";

import Components3PagesTableList from "@/pages/TableList";

import Components4PagesDashboard from "@/pages/Dashboard";

import Components5PagesDashboard from "@/pages/Dashboard";

import Components6PagesDemo from "@/pages/Demo";

import Components7UiwAdminExceptionsLibExceptions403 from "@uiw-admin/exceptions/lib/Exceptions/403";

import Components8UiwAdminExceptionsLibExceptions500 from "@uiw-admin/exceptions/lib/Exceptions/500";

import Components9UiwAdminExceptionsLibExceptions404 from "@uiw-admin/exceptions/lib/Exceptions/404";

import Components10PagesDemo from "@/pages/Demo";


export default [{
  "path": "/login",
  "element": React.lazy(() => import("@/layouts/UserLayout")),
  loader: Components0LayoutsUserLayout.loader
}, {
  "path": "/",
  "element": React.lazy(() => import("@/layouts/BasicLayout")),
  "children": [{
    "index": true,
    "redirect": "/tableList",
    element: <Navigate to="/tableList" />
  }, {
    "path": "/tableList",
    "name": "查询表格",
    "element": React.lazy(() => import("@/pages/TableList")),
    "icon": "search",
    loader: Components2PagesTableList.loader
  }, {
    "path": "/home",
    "name": "首页",
    "element": React.lazy(() => import("@/pages/TableList")),
    "icon": "home",
    loader: Components3PagesTableList.loader
  }, {
    "path": "/:group/*",
    "name": "测试点击页面",
    "hideInMenu": true,
    "component": "@/pages/TableList",
    "icon": "home"
  }, {
    "path": "/dom",
    "name": "子项",
    "icon": "copy",
    "isAuth": true,
    "side": true,
    "children": [{
      "index": true,
      "redirect": "/dom/dashboard",
      "element": React.lazy(() => import("@/pages/Dashboard")),
      element: <Navigate to="/dom/dashboard" />,
      loader: Components4PagesDashboard.loader
    }, {
      "path": "/dom/dashboard",
      "name": "Dashboard",
      "isAuth": true,
      "element": React.lazy(() => import("@/pages/Dashboard")),
      loader: Components5PagesDashboard.loader
    }, {
      "path": "/dom/demo",
      "name": "Dashboard2",
      "element": React.lazy(() => import("@/pages/Demo")),
      "icon": "home",
      loader: Components6PagesDemo.loader
    }, {
      "path": "/dom/exceptions",
      "name": "异常12",
      "icon": "warning-o",
      "side": true,
      "children": [{
        "index": true,
        "redirect": "/dom/exceptions/403",
        element: <Navigate to="/dom/exceptions/403" />
      }, {
        "path": "/dom/exceptions/403",
        "name": "403-1",
        "element": React.lazy(() => import("@uiw-admin/exceptions/lib/Exceptions/403")),
        loader: Components7UiwAdminExceptionsLibExceptions403.loader
      }, {
        "path": "/dom/exceptions/500",
        "name": "500-1",
        "element": React.lazy(() => import("@uiw-admin/exceptions/lib/Exceptions/500")),
        loader: Components8UiwAdminExceptionsLibExceptions500.loader
      }, {
        "path": "/dom/exceptions/404",
        "name": "404-1",
        "element": React.lazy(() => import("@uiw-admin/exceptions/lib/Exceptions/404")),
        loader: Components9UiwAdminExceptionsLibExceptions404.loader
      }]
    }]
  }, {
    "path": "/demo",
    "name": "列表查询/新增demo",
    "element": React.lazy(() => import("@/pages/Demo")),
    "icon": "home",
    loader: Components10PagesDemo.loader
  }],
  loader: Components1LayoutsBasicLayout.loader
}];
