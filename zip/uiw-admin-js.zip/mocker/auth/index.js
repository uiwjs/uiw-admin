module.exports.authList = [
  '/tableList',
  '/home',
  '/demo',
  '/dom',
  '/dom/*',
  '/tableList/:id',
  '/exceptions',
  '/exceptions/403',
  '/exceptions/404',
  '/exceptions/500',
]
