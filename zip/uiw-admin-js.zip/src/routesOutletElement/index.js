import { cloneElement } from 'react';
import { SWRConfig } from 'swr';
import { request } from '@uiw-admin/utils';
import '@uiw/reset.css';
import './index.css';
const RoutesOutletElement = props => {
  const {
    routes
  } = props;
  return <SWRConfig value={{
    fetcher: (resource, init) => {
      return request(resource, init);
    },
    provider: () => new Map()
  }}>
      {cloneElement(props.children, {
      router: routes
    })}
    </SWRConfig>;
};
export default RoutesOutletElement;