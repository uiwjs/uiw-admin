import { cloneElement } from 'react';
import '@uiw/reset.css';
import './index.css';
const RoutesOutletElement = props => {
  const {
    routes
  } = props;
  return cloneElement(props.children, {
    router: routes
  });
};
export default RoutesOutletElement;