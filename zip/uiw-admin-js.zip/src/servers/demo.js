import { request } from '@uiw-admin/utils'; // /api/demo/selectById

function selectById(params) {
  return request('/api/demo/selectById', {
    method: 'POST',
    body: { ...params
    }
  });
}

const update = '/api/demo/update';
const insert = '/api/demo/insert';
export { selectById, update, insert };