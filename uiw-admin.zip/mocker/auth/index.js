module.exports.authList = [
  '/tableList',
  '/home',
  '/dom',
  '/dom/courses',
  '/dom/home',
  '/demo',
  '/exceptions',
  '/exceptions/403',
  '/exceptions/404',
  '/exceptions/500',
];
