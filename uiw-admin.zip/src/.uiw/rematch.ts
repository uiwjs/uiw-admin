
import {
  init,
  Models,
  Model,
  createModel
} from '@rematch/core';
import loading, { ExtraModelsFromLoading } from '@rematch/loading';

export interface RootModel extends Models<RootModel> {
}
type FullModel = ExtraModelsFromLoading<RootModel>

export const store = init<RootModel, FullModel>({
  models: {},
  plugins: [loading()],
});

export const { addModel } = store;

export const createModels = (model: Model<RootModel>, name: string) => {
  const models = createModel<RootModel>()(model)
  addModel({ name, ...models })
}
createModels(require("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc.ts").default,"doc");
createModels(require("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo.ts").default,"demo");
createModels(require("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global.ts").default,"global");
createModels(require("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home.ts").default,"home");
createModels(require("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login.ts").default,"login");

