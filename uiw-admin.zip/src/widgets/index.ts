import { Slider } from 'uiw'
export const customWidgetsList = {
  slider: Slider
}