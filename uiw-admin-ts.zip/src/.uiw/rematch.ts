
// @ts-ignore
import {
  init,
  Models,
  Model,
  RematchRootState,
  RematchDispatch,
  createModel,
} from '@rematch/core';
import loading, { ExtraModelsFromLoading } from '@rematch/loading';
import docModel0 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc";
import demoModel1 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo";
import globalModel2 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global";
import homeModel3 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home";
import loginModel4 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login";
import docDsModel5 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/pages/Dashboard/models/index";
import docDModel6 from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/pages/Demo/models/index";

const docModel = docModel0;
const demoModel = demoModel1;
const globalModel = globalModel2;
const homeModel = homeModel3;
const loginModel = loginModel4;
const docDsModel = docDsModel5;
const docDModel = docDModel6;

export const models = {
  doc:docModel,
demo:demoModel,
global:globalModel,
home:homeModel,
login:loginModel,
docDs:docDsModel,
docD:docDModel,

}
export interface RootModel extends Models<RootModel> {
   doc:typeof  docModel0,
 demo:typeof  demoModel1,
 global:typeof  globalModel2,
 home:typeof  homeModel3,
 login:typeof  loginModel4,
 docDs:typeof  docDsModel5,
 docD:typeof  docDModel6,

}
export type FullModel = ExtraModelsFromLoading<RootModel>

export const store = init<RootModel, FullModel>({
  models,
  plugins: [loading()],
});

export const { dispatch, addModel } = store;
export type Store = typeof store;
export type AddModel = typeof addModel;
export type Dispatch = RematchDispatch<RootModel>;
export type RootState = RematchRootState<RootModel, FullModel>;
export type ModelDefault<T = any> = Model<RootModel, T>;

