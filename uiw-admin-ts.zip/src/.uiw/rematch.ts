
// @ts-ignore
import {
  init,
  Models,
  Model,
  RematchRootState,
  RematchDispatch,
  createModel,
} from '@rematch/core';
import loading, { ExtraModelsFromLoading } from '@rematch/loading';
import doc from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc";
import demo from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo";
import global from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global";
import home from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home";
import login from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login";

const docModel = doc;
const demoModel = demo;
const globalModel = global;
const homeModel = home;
const loginModel = login;

export const models = {
   doc:docModel,
 demo:demoModel,
 global:globalModel,
 home:homeModel,
 login:loginModel,

}
export interface RootModel extends Models<RootModel> {
   doc:typeof  docModel,
 demo:typeof  demoModel,
 global:typeof  globalModel,
 home:typeof  homeModel,
 login:typeof  loginModel,

}
export type FullModel = ExtraModelsFromLoading<RootModel>

export const store = init<RootModel, FullModel>({
  models,
  plugins: [loading()],
});

export const { dispatch, addModel } = store;
export type Store = typeof store;
export type AddModel = typeof addModel;
export type Dispatch = RematchDispatch<RootModel>;
export type RootState = RematchRootState<RootModel, FullModel>;
export type ModelDefault<T = any> = Model<RootModel, T>;

