
// @ts-ignore
import {
  init,
  Models,
  Model,
  RematchRootState,
  RematchDispatch,
  createModel,
} from '@rematch/core';
import loading, { ExtraModelsFromLoading } from '@rematch/loading';
import docModel from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc";
import demoModel from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo";
import globalModel from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global";
import homeModel from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home";
import loginModel from "/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login";


export interface RootModel extends Models<RootModel> {
   doc:typeof  docModel,
 demo:typeof  demoModel,
 global:typeof  globalModel,
 home:typeof  homeModel,
 login:typeof  loginModel,

}
export type FullModel = ExtraModelsFromLoading<RootModel>

export const store = init<RootModel, FullModel>({
  models:{},
  plugins: [loading()],
});

const getStore = async () => {
  const docModel = (await import("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/Doc/doc")).default;
const demoModel = (await import("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/demo")).default;
const globalModel = (await import("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/global")).default;
const homeModel = (await import("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/home")).default;
const loginModel = (await import("/home/runner/work/uiw-admin/uiw-admin/examples/base/src/models/login")).default;

  store.addModel({ name: "doc", ...docModel });
store.addModel({ name: "demo", ...demoModel });
store.addModel({ name: "global", ...globalModel });
store.addModel({ name: "home", ...homeModel });
store.addModel({ name: "login", ...loginModel });

  return store
}

getStore()

export const { dispatch, addModel } = store;
export type Store = typeof store;
export type AddModel = typeof addModel;
export type Dispatch = RematchDispatch<RootModel>;
export type RootState = RematchRootState<RootModel, FullModel>;
export type ModelDefault<T = any> = Model<RootModel, T>;

