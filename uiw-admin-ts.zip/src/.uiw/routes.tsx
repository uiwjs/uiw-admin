
// @ts-nocheck
import React from "react";
import { Search as Search_Icon } from "@uiw/icons/lib/Search";
import { Home as Home_Icon } from "@uiw/icons/lib/Home";
import { Copy as Copy_Icon } from "@uiw/icons/lib/Copy";
import { WarningO as WarningO_Icon } from "@uiw/icons/lib/WarningO";
import { Component as Component_Icon } from "@uiw/icons/lib/Component";

import {Exceptions404,Exceptions403,Exceptions500 } from "@uiw-admin/exceptions"
import ComponentsLayoutsUserLayout from "@/layouts/UserLayout"
import ComponentsLayoutsBasicLayout from "@/layouts/BasicLayout"
import ComponentsPagesTableList from "@/pages/TableList"
import ComponentsPagesDashboard from "@/pages/Dashboard"
import ComponentsPagesDemo from "@/pages/Demo"

export default [{
  "path": "/login",
  "component": <ComponentsLayoutsUserLayout />,
  loader: ComponentsLayoutsUserLayout.loader
}, {
  "path": "/",
  "component": <ComponentsLayoutsBasicLayout />,
  "routes": [{
    "index": true,
    "redirect": "/tableList"
  }, {
    "path": "/tableList",
    "name": "查询表格",
    "component": <ComponentsPagesTableList />,
    "icon": <Search_Icon />,
    "navigate": navigate => {
      navigate('/tableList', {
        replace: true
      });
    },
    loader: ComponentsPagesTableList.loader
  }, {
    "path": "/tableList/:id",
    "name": "查询表格2",
    "component": <ComponentsPagesTableList />,
    "icon": <Search_Icon />,
    "navigate": navigate => {
      navigate('/tableList', {
        replace: true
      });
    },
    loader: ComponentsPagesTableList.loader
  }, {
    "path": "/home",
    "name": "首页",
    "component": <ComponentsPagesTableList />,
    "icon": <Home_Icon />,
    loader: ComponentsPagesTableList.loader
  }, {
    "path": "/dom",
    "name": "子项",
    "icon": <Copy_Icon />,
    "isAuth": true,
    "side": true,
    "routes": [{
      "index": true,
      "path": "/dom/courses",
      "name": "Dashboard",
      "isAuth": true,
      "component": <ComponentsPagesDashboard />,
      loader: ComponentsPagesDashboard.loader
    }, {
      "path": "/dom/exceptions",
      "name": "异常12",
      "icon": <WarningO_Icon />,
      "side": true,
      "routes": [{
        "index": true,
        "path": "/dom/exceptions/403",
        "name": "403-1",
        "component": <Exceptions403 />
      }, {
        "path": "/dom/exceptions/500",
        "name": "500-1",
        "component": <Exceptions500 />
      }, {
        "path": "/dom/exceptions/404",
        "name": "404-1",
        "component": <Exceptions404 />
      }]
    }]
  }, {
    "path": "/demo",
    "name": "列表查询/新增demo",
    "component": <ComponentsPagesDemo />,
    "icon": <Component_Icon />,
    loader: ComponentsPagesDemo.loader
  }, {
    "path": "/exceptions",
    "name": "异常",
    "icon": <WarningO_Icon />,
    "routes": [{
      "path": "/exceptions/403",
      "name": "403",
      "component": <Exceptions403 />
    }, {
      "path": "/exceptions/500",
      "name": "500",
      "component": <Exceptions500 />
    }, {
      "path": "/exceptions/404",
      "name": "404",
      "component": <Exceptions404 />
    }]
  }, {
    "path": "/403",
    "name": "403",
    "hideInMenu": true,
    "component": <Exceptions403 />
  }, {
    "path": "/500",
    "name": "500",
    "hideInMenu": true,
    "component": <Exceptions500 />
  }, {
    "path": "/404",
    "name": "404",
    "hideInMenu": true,
    "component": <Exceptions404 />
  }, {
    "path": "*",
    "name": "404",
    "component": <Exceptions404 />
  }],
  loader: ComponentsLayoutsBasicLayout.loader
}];;
